package com.bookstore.model.db.auth;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER,
    ;
}
